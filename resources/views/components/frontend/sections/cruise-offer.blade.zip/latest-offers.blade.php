<!-- Start -->
<div class="container mb-2">
    <div id="latest_offers1" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <div class="row">
                    <div class="col-sm-4">
                        <div class="card shadow" style="height:200px;">
                            <h4 class="text-center font-weight-bold m-0 p-2">Bank Offer</h4>
                            <div class="smsteng">
                                <div class="lftssasert">
                                    <img src="assets/images/flight/travel(1).png" alt="">
                                </div>
                                <div class="rightssear">
                                    <h5 class="text-center font-weight-bold p-1 m-0">Flight</h5>
                                    <p class="small p-1  m-0">Book up to 4 different routes in a single go by choosing
                                        different flights for each route on our Multi-City option</p>
                                    <button class="float-right mr-3"><i class="fa fa-angle-right"
                                            aria-hidden="true"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="card">
                            <div class="card shadow" style="height:200px;">
                                <h4 class="text-center font-weight-bold m-0 p-2">Bank Offer</h4>
                                <div class="smsteng">
                                    <div class="lftssasert">
                                        <img src="assets/images/flight/travel(1).png" alt="">
                                    </div>
                                    <div class="rightssear">
                                        <h5 class="text-center font-weight-bold p-1 m-0">Hotel</h5>
                                        <p class="small p-1  m-0">Book up to 4 different routes in a single go by
                                            choosing different flights for each route on our Multi-City option</p>
                                        <button class="float-right mr-3"><i class="fa fa-angle-right"
                                                aria-hidden="true"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="card">
                            <div class="card shadow" style="height:200px;">
                                <h4 class="text-center font-weight-bold m-0 p-2">Bank Offer</h4>
                                <div class="smsteng">
                                    <div class="lftssasert">
                                        <img src="assets/images/flight/travel(1).png" alt="">
                                    </div>
                                    <div class="rightssear">
                                        <h5 class="text-center font-weight-bold p-1 m-0">Holiday</h5>
                                        <p class="small p-1  m-0">Book up to 4 different routes in a single go by
                                            choosing different flights for each route on our Multi-City option</p>
                                        <button class="float-right mr-3"><i class="fa fa-angle-right"
                                                aria-hidden="true"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="carousel-item">
                <div class="row">
                    <div class="col-sm-4">
                        <div class="card shadow" style="height:200px;">
                            <h4 class="text-center font-weight-bold m-0 p-2">Bank Offer</h4>
                            <div class="smsteng">
                                <div class="lftssasert">
                                    <img src="assets/images/flight/travel(1).png" alt="">
                                </div>
                                <div class="rightssear">
                                    <h5 class="text-center font-weight-bold p-1 m-0">Flight</h5>
                                    <p class="small p-1  m-0">Book up to 4 different routes in a single go by choosing
                                        different flights for each route on our Multi-City option</p>
                                    <button class="float-right mr-3"><i class="fa fa-angle-right"
                                            aria-hidden="true"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="card">
                            <div class="card shadow" style="height:200px;">
                                <h4 class="text-center font-weight-bold m-0 p-2">Bank Offer</h4>
                                <div class="smsteng">
                                    <div class="lftssasert">
                                        <img src="assets/images/flight/travel(1).png" alt="">
                                    </div>
                                    <div class="rightssear">
                                        <h5 class="text-center font-weight-bold p-1 m-0">Hotel</h5>
                                        <p class="small p-1  m-0">Book up to 4 different routes in a single go by
                                            choosing different flights for each route on our Multi-City option</p>
                                        <button class="float-right mr-3"><i class="fa fa-angle-right"
                                                aria-hidden="true"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="card">
                            <div class="card shadow" style="height:200px;">
                                <h4 class="text-center font-weight-bold m-0 p-2">Bank Offer</h4>
                                <div class="smsteng">
                                    <div class="lftssasert">
                                        <img src="assets/images/flight/travel(1).png" alt="">
                                    </div>
                                    <div class="rightssear">
                                        <h5 class="text-center font-weight-bold p-1 m-0">Holiday</h5>
                                        <p class="small p-1  m-0">Book up to 4 different routes in a single go by
                                            choosing different flights for each route on our Multi-City option</p>
                                        <button class="float-right mr-3"><i class="fa fa-angle-right"
                                                aria-hidden="true"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="carousel-item">
                <div class="row">
                    <div class="col-sm-4">
                        <div class="card shadow" style="height:200px;">
                            <h4 class="text-center font-weight-bold m-0 p-2">Bank Offer</h4>
                            <div class="smsteng">
                                <div class="lftssasert">
                                    <img src="assets/images/flight/travel(1).png" alt="">
                                </div>
                                <div class="rightssear">
                                    <h5 class="text-center font-weight-bold p-1 m-0">Flight</h5>
                                    <p class="small p-1  m-0">Book up to 4 different routes in a single go by choosing
                                        different flights for each route on our Multi-City option</p>
                                    <button class="float-right mr-3"><i class="fa fa-angle-right"
                                            aria-hidden="true"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="card">
                            <div class="card shadow" style="height:200px;">
                                <h4 class="text-center font-weight-bold m-0 p-2">Bank Offer</h4>
                                <div class="smsteng">
                                    <div class="lftssasert">
                                        <img src="assets/images/flight/travel(1).png" alt="">
                                    </div>
                                    <div class="rightssear">
                                        <h5 class="text-center font-weight-bold p-1 m-0">Hotel</h5>
                                        <p class="small p-1  m-0">Book up to 4 different routes in a single go by
                                            choosing different flights for each route on our Multi-City option</p>
                                        <button class="float-right mr-3"><i class="fa fa-angle-right"
                                                aria-hidden="true"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="card">
                            <div class="card shadow" style="height:200px;">
                                <h4 class="text-center font-weight-bold m-0 p-2">Bank Offer</h4>
                                <div class="smsteng">
                                    <div class="lftssasert">
                                        <img src="assets/images/flight/travel(1).png" alt="">
                                    </div>
                                    <div class="rightssear">
                                        <h5 class="text-center font-weight-bold p-1 m-0">Holiday</h5>
                                        <p class="small p-1  m-0">Book up to 4 different routes in a single go by
                                            choosing different flights for each route on our Multi-City option</p>
                                        <button class="float-right mr-3"><i class="fa fa-angle-right"
                                                aria-hidden="true"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- <a class="carousel-control-prev" href="#latest_offers1" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#latest_offers1" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a> -->
    </div>
</div>
<!-- End -->
