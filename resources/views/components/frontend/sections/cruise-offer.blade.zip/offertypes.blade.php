<!-- Desktop View -->
<div class="container borsershoadws mt-5">
    <div class="row">
        <div class="col-sm-4">
            <h1 style="margin:0px; font-size: 28px; font-weight: 600; color: #000;">MTT Exclusive Offers</h1>
        </div>
        <div class="col-sm-8">
            <ul class="best_ofersMttt">
                <li class="tablinks_offer1" onclick="openCity(event, 'offers_12')" id="defaultOpen5">All Offer</li>
                <li class="tablinks_offer1" onclick="openCity(event, 'offers_13')">Flights</li>
                <li class="tablinks_offer1" onclick="openCity(event, 'offers_14')">Hotels</li>
                <li class="tablinks_offer1" onclick="openCity(event, 'offers_15')">Holidays</li>
                <li class="tablinks_offer1" onclick="openCity(event, 'offers_16')">Others</li>
            </ul>
        </div>
    </div>
    <!-- <div class="tab">
        <button class="tablinks" onclick="openCity(event, 'London')" id="defaultOpen">London</button>
        <button class="tablinks" onclick="openCity(event, 'Paris')">Paris</button>
        <button class="tablinks" onclick="openCity(event, 'Tokyo')">Tokyo</button>
    </div> -->
    <div class="container p-3 mt-3" style="background-color:#eee; box-shadow: rgba(0, 0, 0, 0.25) 0px 0.0625em 0.0625em, rgba(0, 0, 0, 0.25) 0px 0.125em 0.5em, rgba(255, 255, 255, 0.1) 0px 0px 0px 1px inset;">
        <div id="offers_12" class="tabcontent_offers12">
            <div id="offers_sliderBox1" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <div id="offers_13" class="tabcontent_offers12">
            <div id="offers_sliderBox1" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <div id="offers_14" class="tabcontent_offers12">
            <div id="offers_sliderBox1" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <div id="offers_15" class="tabcontent_offers12">
            <div id="offers_sliderBox1" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <div id="offers_16" class="tabcontent_offers12">
            <div id="offers_sliderBox1" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <img src="assets/images/flynow-hp.png" alt="" style="width:100px;">
                                        </div>
                                        <div class="col-sm-8">
                                            <h4
                                                style="font-size: 18px; font-weight: 700; color: #000; margin-bottom: 5px; padding-top:20px;">
                                                Special Flight Deal</h4>
                                            <P style="font-size: 12px; font-weight: 400; color: #000;">Book your Travel
                                                with Us & Enjoy 10% off up to Rs.1000</P>
                                        </div>
                                    </div>
                                    <div class="other_sdetailsOffer">
                                        <div class="one_offers15">
                                            <p><a href="#">T&C's Apply</a></p>
                                        </div>
                                        <div class="one_offers16">
                                            <h6>Code: MTT250</h6>
                                        </div>
                                        <div class="one_offers17">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <div class="offersButtons_12">
        <span href="#offers_sliderBox1" role="button" data-slide="prev"><i class="fa fa-angle-left"
                aria-hidden="true"></i></span>
        <span href="#offers_sliderBox1" role="button" data-slide="next"><i class="fa fa-angle-right"
                aria-hidden="true"></i></span>
    </div>

</div>

<script>
    function openCity(evt, cityName) {
        var i, tabcontent_offers12, tablinks_offer1;
        tabcontent_offers12 = document.getElementsByClassName("tabcontent_offers12");
        for (i = 0; i < tabcontent_offers12.length; i++) {
            tabcontent_offers12[i].style.display = "none";
        }
        tablinks_offer1 = document.getElementsByClassName("tablinks_offer1");
        for (i = 0; i < tablinks_offer1.length; i++) {
            tablinks_offer1[i].className = tablinks_offer1[i].className.replace(" active", "");
        }
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active";
    }

    document.getElementById("defaultOpen5").click();

</script>
<!-- End View -->
