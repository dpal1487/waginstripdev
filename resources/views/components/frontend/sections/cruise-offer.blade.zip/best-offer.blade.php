<!-- Start -->

<div class="bestOffersSection1">
    <h4>BEST OFFERS</h4>
    <div class="bestCardBtn">
        <span href="#carouselExampleControls" role="button" data-slide="prev"><i class="fa fa-chevron-left"
                aria-hidden="true"></i></span>
        <span href="#carouselExampleControls" role="button" data-slide="next"><i class="fa fa-chevron-right"
                aria-hidden="true"></i></span>
    </div>
    <div class="bestCardSections">
        <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <div class="bestCardSliderBox1">
                        <a href="{{ url('') }}">
                            <div class="bestBoxCard-1">
                                <img src="assets/images/hotel/room1.jpg" alt="">
                                <h4>Types of Room</h4>
                                <h5>Lorem ipsum dolor sit </h5>
                                <h6>Lorem ipsum dolor</h6>
                                <h5 class="m-0 pt-4 text-danger float-left">Save 20%</h5>
                                <h3><del>₹5,350</del> <span>₹4,500</span></h3>
                            </div>
                        </a>
                        <a href="{{ url('') }}">
                            <div class="bestBoxCard-2">
                                <img src="assets/images/hotel/room1.jpg" alt="">
                                <h4>Types of Room</h4>
                                <h5>Lorem ipsum dolor sit </h5>
                                <h6>Lorem ipsum dolor</h6>
                                <h5 class="m-0 pt-4 text-danger float-left">Save 20%</h5>
                                <h3><del>₹5,350</del> <span>₹4,500</span></h3>
                            </div>
                        </a>
                        <a href="{{ url('') }}">
                            <div class="bestBoxCard-3">
                                <img src="assets/images/hotel/room1.jpg" alt="">
                                <h4>Types of Room</h4>
                                <h5>Lorem ipsum dolor sit </h5>
                                <h6>Lorem ipsum dolor</h6>
                                <h5 class="m-0 pt-4 text-danger float-left">Save 20%</h5>
                                <h3><del>₹5,350</del> <span>₹4,500</span></h3>
                            </div>
                        </a>
                        <a href="{{ url('') }}">
                            <div class="bestBoxCard-4">
                                <img src="assets/images/hotel/room1.jpg" alt="">
                                <h4>Types of Room</h4>
                                <h5>Lorem ipsum dolor sit </h5>
                                <h6>Lorem ipsum dolor</h6>
                                <h5 class="m-0 pt-4 text-danger float-left">Save 20%</h5>
                                <h3><del>₹5,350</del> <span>₹4,500</span></h3>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="bestCardSliderBox1">
                        <a href="{{ url('') }}">
                            <div class="bestBoxCard-1">
                                <img src="assets/images/hotel/room1.jpg" alt="">
                                <h4>Types of Room</h4>
                                <h5>Lorem ipsum dolor sit </h5>
                                <h6>Lorem ipsum dolor</h6>
                                <h5 class="m-0 pt-4 text-danger float-left">Save 20%</h5>
                                <h3><del>₹5,350</del> <span>₹4,500</span></h3>
                            </div>
                        </a>
                        <a href="{{ url('') }}">
                            <div class="bestBoxCard-2">
                                <img src="assets/images/hotel/room1.jpg" alt="">
                                <h4>Types of Room</h4>
                                <h5>Lorem ipsum dolor sit </h5>
                                <h6>Lorem ipsum dolor</h6>
                                <h5 class="m-0 pt-4 text-danger float-left">Save 20%</h5>
                                <h3><del>₹5,350</del> <span>₹4,500</span></h3>
                            </div>
                        </a>
                        <a href="{{ url('') }}">
                            <div class="bestBoxCard-3">
                                <img src="assets/images/hotel/room1.jpg" alt="">
                                <h4>Types of Room</h4>
                                <h5>Lorem ipsum dolor sit </h5>
                                <h6>Lorem ipsum dolor</h6>
                                <h5 class="m-0 pt-4 text-danger float-left">Save 20%</h5>
                                <h3><del>₹5,350</del> <span>₹4,500</span></h3>
                            </div>
                        </a>
                        <a href="{{ url('') }}">
                            <div class="bestBoxCard-4">
                                <img src="assets/images/hotel/room1.jpg" alt="">
                                <h4>Types of Room</h4>
                                <h5>Lorem ipsum dolor sit </h5>
                                <h6>Lorem ipsum dolor</h6>
                                <h5 class="m-0 pt-4 text-danger float-left">Save 20%</h5>
                                <h3><del>₹5,350</del> <span>₹4,500</span></h3>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="bestCardSliderBox1">
                        <a href="{{ url('') }}">
                            <div class="bestBoxCard-1">
                                <img src="assets/images/hotel/room1.jpg" alt="">
                                <h4>Types of Room</h4>
                                <h5>Lorem ipsum dolor sit </h5>
                                <h6>Lorem ipsum dolor</h6>
                                <h5 class="m-0 pt-4 text-danger float-left">Save 20%</h5>
                                <h3><del>₹5,350</del> <span>₹4,500</span></h3>
                            </div>
                        </a>
                        <a href="{{ url('') }}">
                            <div class="bestBoxCard-2">
                                <img src="assets/images/hotel/room1.jpg" alt="">
                                <h4>Types of Room</h4>
                                <h5>Lorem ipsum dolor sit </h5>
                                <h6>Lorem ipsum dolor</h6>
                                <h5 class="m-0 pt-4 text-danger float-left">Save 20%</h5>
                                <h3><del>₹5,350</del> <span>₹4,500</span></h3>
                            </div>
                        </a>
                        <a href="{{ url('') }}">
                            <div class="bestBoxCard-3">
                                <img src="assets/images/hotel/room1.jpg" alt="">
                                <h4>Types of Room</h4>
                                <h5>Lorem ipsum dolor sit </h5>
                                <h6>Lorem ipsum dolor</h6>
                                <h5 class="m-0 pt-4 text-danger float-left">Save 20%</h5>
                                <h3><del>₹5,350</del> <span>₹4,500</span></h3>
                            </div>
                        </a>
                        <a href="{{ url('') }}">
                            <div class="bestBoxCard-4">
                                <img src="assets/images/hotel/room1.jpg" alt="">
                                <h4>Types of Room</h4>
                                <h5>Lorem ipsum dolor sit </h5>
                                <h6>Lorem ipsum dolor</h6>
                                <h5 class="m-0 pt-4 text-danger float-left">Save 20%</h5>
                                <h3><del>₹5,350</del> <span>₹4,500</span></h3>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- End -->
