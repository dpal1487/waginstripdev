<!-- Start -->

<div class="specialOfferSlider1">
    <h4 class="m-0 pt-2 font-weight-bold"><span>SPECIAL</span> <span>OFFER</span></h4>
    <div class="specialBtn15">
        <span href="#sliderButtonClicks" role="button" data-slide="prev"><i class="fa fa-angle-left"
                aria-hidden="true"></i></span>
        <span href="#sliderButtonClicks" role="button" data-slide="next"><i class="fa fa-angle-right"
                aria-hidden="true"></i></span>
    </div>
    <hr>

    <div class="specialOffers-100">
        <div id="sliderButtonClicks" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <div class="cardSliderOne1">
                        <a href="{{ url('') }}">
                            <div class="slider-100">
                                <div class="priceTagSlider1">
                                    <p>Offer*</p>
                                    <h3>₹55,599</h3>
                                </div>
                                <div class="tagLineNameCity">
                                    <h4>BANGKOK</h4>
                                </div>
                            </div>
                        </a>
                        <a href="{{ url('') }}">
                            <div class="slider-101">
                                <div class="priceTagSlider1">
                                    <p>Offer*</p>
                                    <h3>₹55,599</h3>
                                </div>
                                <div class="tagLineNameCity">
                                    <h4>BANGKOK</h4>
                                </div>
                            </div>
                        </a>
                        <a href="{{ url('') }}">
                            <div class="slider-102">
                                <div class="priceTagSlider1">
                                    <p>Offer*</p>
                                    <h3>₹55,599</h3>
                                </div>
                                <div class="tagLineNameCity">
                                    <h4>BANGKOK</h4>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="cardSliderOne1">
                        <a href="{{ url('') }}">
                            <div class="slider-100">
                                <div class="priceTagSlider1">
                                    <p>Offer*</p>
                                    <h3>₹55,599</h3>
                                </div>
                                <div class="tagLineNameCity">
                                    <h4>BANGKOK</h4>
                                </div>
                            </div>
                        </a>
                        <a href="{{ url('') }}">
                            <div class="slider-101">
                                <div class="priceTagSlider1">
                                    <p>Offer*</p>
                                    <h3>₹55,599</h3>
                                </div>
                                <div class="tagLineNameCity">
                                    <h4>BANGKOK</h4>
                                </div>
                            </div>
                        </a>
                        <a href="{{ url('') }}">
                            <div class="slider-102">
                                <div class="priceTagSlider1">
                                    <p>Offer*</p>
                                    <h3>₹55,599</h3>
                                </div>
                                <div class="tagLineNameCity">
                                    <h4>BANGKOK</h4>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="cardSliderOne1">
                        <a href="{{ url('') }}">
                            <div class="slider-100">
                                <div class="priceTagSlider1">
                                    <p>Offer*</p>
                                    <h3>₹55,599</h3>
                                </div>
                                <div class="tagLineNameCity">
                                    <h4>BANGKOK</h4>
                                </div>
                            </div>
                        </a>
                        <a href="{{ url('') }}">
                            <div class="slider-101">
                                <div class="priceTagSlider1">
                                    <p>Offer*</p>
                                    <h3>₹55,599</h3>
                                </div>
                                <div class="tagLineNameCity">
                                    <h4>BANGKOK</h4>
                                </div>
                            </div>
                        </a>
                        <a href="{{ url('') }}">
                            <div class="slider-102">
                                <div class="priceTagSlider1">
                                    <p>Offer*</p>
                                    <h3>₹55,599</h3>
                                </div>
                                <div class="tagLineNameCity">
                                    <h4>BANGKOK</h4>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- End -->
