<div class="container-fluid bg-darksar p-0">
<div class="container mobileVes1 marthide pt-5 pb-3 text-white">
    <h6 class="font-weight-bold"> Our Products </h6>
    <ul class="list-unstyled listed_links">
        <li><a href="{{url('/')}}">Flight</a></li>
        <li><a href="{{url('hotels')}}">Hotel</a></li>
        <li><a href="{{url('holiday')}}">Holiday</a></li>
        <li><a href="{{url('cruise')}}">Cruise</a></li>
        <li><a href="{{url('visa')}}">Visa</a></li>
        <li><a href="{{url('about-pages')}}">About Us</a></li>
        <li><a href="{{url('careerspages')}}">Careers</a></li>
        <li><a href="{{url('contact')}}">Contact Us</a></li>
        <li><a href="{{url('terms-and-conditions')}}">Terms and Conditions</a></li>
        <li><a href="{{url('user-agreement')}}">User Agreement</a></li>
        <li><a href="{{url('privacy-policy')}}">Privacy Policy</a></li>
        <li><a href="{{url('activities-main')}}">Activities Tours</a></li>
        <li><a href="{{url('blog-page')}}">Blog</a></li>
    </ul>
</div>
</div>
