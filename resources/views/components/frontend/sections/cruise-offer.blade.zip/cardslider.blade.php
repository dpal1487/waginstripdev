<div class="trandingPages1">
    <h1>Insta-worthy Activities</h1>
    <div class="activitiesLandingBtn1">
        <span href="#carouselExampleIndicators2" role="button" data-slide="prev"><i class="fa fa-angle-left"
                aria-hidden="true"></i></span>
        <span href="#carouselExampleIndicators2" role="button" data-slide="next"><i class="fa fa-angle-right"
                aria-hidden="true"></i></span>
    </div>
    <div class="cardsldr5">
        <div id="carouselExampleIndicators2" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <div class="fristSliderBx1">
                        <a href="{{ url('activities-tours') }}">
                            <div class="fSldr1">
                                <img src="../assets/images/activities/1.jpg" alt="">
                                <h5>Lorem ipsum dolor, sit amet consectetur...</h5>
                                <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                <i class="fa fa-star-o" aria-hidden="true"></i>
                                <i class="fa fa-star-o" aria-hidden="true"></i>
                                <p>171 Ratings</p>
                                <h6 class="text-right text-muted"><del>₹15,400</del></h6>
                                <h4 class="text-right">₹10,500</h4>
                                <p class="text-right small text-muted m-0">Per Person</p>
                            </div>
                        </a>
                        <a href="{{ url('activities-tours') }}">
                            <div class="fSldr2">
                                <img src="../assets/images/activities/2.jpg" alt="">
                                <h5>Lorem ipsum dolor, sit amet consectetur...</h5>
                                <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                <i class="fa fa-star-o" aria-hidden="true"></i>
                                <i class="fa fa-star-o" aria-hidden="true"></i>
                                <p>171 Ratings</p>
                                <h6 class="text-right text-muted"><del>₹15,400</del></h6>
                                <h4 class="text-right">₹10,500</h4>
                                <p class="text-right small text-muted m-0">Per Person</p>
                            </div>
                        </a>
                        <a href="{{ url('activities-tours') }}">
                            <div class="fSldr3">
                                <img src="../assets/images/activities/3.jpg" alt="">
                                <h5>Lorem ipsum dolor, sit amet consectetur...</h5>
                                <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                <i class="fa fa-star-o" aria-hidden="true"></i>
                                <i class="fa fa-star-o" aria-hidden="true"></i>
                                <p>171 Ratings</p>
                                <h6 class="text-right text-muted"><del>₹15,400</del></h6>
                                <h4 class="text-right">₹10,500</h4>
                                <p class="text-right small text-muted m-0">Per Person</p>
                            </div>
                        </a>
                        <a href="{{url('activities-tours')}}">
                            <div class="fSldr4">
                                <img src="../assets/images/activities/4.jpg" alt="">
                                <h5>Lorem ipsum dolor, sit amet consectetur...</h5>
                                <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                <i class="fa fa-star-o" aria-hidden="true"></i>
                                <i class="fa fa-star-o" aria-hidden="true"></i>
                                <p>171 Ratings</p>
                                <h6 class="text-right text-muted"><del>₹15,400</del></h6>
                                <h4 class="text-right">₹10,500</h4>
                                <p class="text-right small text-muted m-0">Per Person</p>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="carousel-item">
                <div class="fristSliderBx1">
                        <a href="{{ url('activities-tours') }}">
                            <div class="fSldr1">
                                <img src="../assets/images/activities/1.jpg" alt="">
                                <h5>Lorem ipsum dolor, sit amet consectetur...</h5>
                                <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                <i class="fa fa-star-o" aria-hidden="true"></i>
                                <i class="fa fa-star-o" aria-hidden="true"></i>
                                <p>171 Ratings</p>
                                <h6 class="text-right text-muted"><del>₹15,400</del></h6>
                                <h4 class="text-right">₹10,500</h4>
                                <p class="text-right small text-muted m-0">Per Person</p>
                            </div>
                        </a>
                        <a href="{{ url('activities-tours') }}">
                            <div class="fSldr2">
                                <img src="../assets/images/activities/2.jpg" alt="">
                                <h5>Lorem ipsum dolor, sit amet consectetur...</h5>
                                <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                <i class="fa fa-star-o" aria-hidden="true"></i>
                                <i class="fa fa-star-o" aria-hidden="true"></i>
                                <p>171 Ratings</p>
                                <h6 class="text-right text-muted"><del>₹15,400</del></h6>
                                <h4 class="text-right">₹10,500</h4>
                                <p class="text-right small text-muted m-0">Per Person</p>
                            </div>
                        </a>
                        <a href="{{ url('activities-tours') }}">
                            <div class="fSldr3">
                                <img src="../assets/images/activities/3.jpg" alt="">
                                <h5>Lorem ipsum dolor, sit amet consectetur...</h5>
                                <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                <i class="fa fa-star-o" aria-hidden="true"></i>
                                <i class="fa fa-star-o" aria-hidden="true"></i>
                                <p>171 Ratings</p>
                                <h6 class="text-right text-muted"><del>₹15,400</del></h6>
                                <h4 class="text-right">₹10,500</h4>
                                <p class="text-right small text-muted m-0">Per Person</p>
                            </div>
                        </a>
                        <a href="{{url('activities-tours')}}">
                            <div class="fSldr4">
                                <img src="../assets/images/activities/4.jpg" alt="">
                                <h5>Lorem ipsum dolor, sit amet consectetur...</h5>
                                <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                <i class="fa fa-star-o" aria-hidden="true"></i>
                                <i class="fa fa-star-o" aria-hidden="true"></i>
                                <p>171 Ratings</p>
                                <h6 class="text-right text-muted"><del>₹15,400</del></h6>
                                <h4 class="text-right">₹10,500</h4>
                                <p class="text-right small text-muted m-0">Per Person</p>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
