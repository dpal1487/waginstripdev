<!-- Destktop View -->

<div class="container flight_sliderOffers mobileVes1 mt-5 mb-5">
    <div class="row btnssreser">
        <div class="col-sm-6">
            <h1 class="float-left font-weight-bold" style="font-size:28px;">
                Best Selling Holiday Packages
            </h1>
        </div>
        <div class="col-sm-6">
            <div class="offersButtons_12 mt-0">
                <span href="#toDestinationsSlider_1" role="button" data-slide="prev"><i class="fa fa-angle-left"
                        aria-hidden="true"></i></span>
                <span href="#toDestinationsSlider_1" role="button" data-slide="next"><i class="fa fa-angle-right"
                        aria-hidden="true"></i></span>
            </div>
        </div>
    </div>
    <div id="toDestinationsSlider_1" class="carousel slide mt-3 mb-3" data-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <div class="row p-2">
                    <div class="col-sm-3 p-2">
                        <a href="#">
                            <div class="card">
                                <img class="card-img-top" src="assets/images/holiday/9.jpg" alt="Card image cap"
                                    style="height:200px;">
                                <div class="card-body">
                                    <h6 class="font-weight-bold">Honeymoon Destinations</h6>
                                    <a class="float-right font-weight-bold text-primary" href="#">Explore</a>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-sm-3 p-2">
                        <a href="#">
                            <div class="card">
                                <img class="card-img-top" src="assets/images/holiday/10.jpg" alt="Card image cap"
                                    style="height:200px;">
                                <div class="card-body">
                                    <h6 class="font-weight-bold">Romantic Destinations</h6>
                                    <a class="float-right font-weight-bold text-primary" href="#">Explore</a>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-sm-3 p-2">
                        <a href="#">
                            <div class="card">
                                <img class="card-img-top" src="assets/images/holiday/11.jpg" alt="Card image cap"
                                    style="height:200px;">
                                <div class="card-body">
                                    <h6 class="font-weight-bold">International Destinations</h6>
                                    <a class="float-right font-weight-bold text-primary" href="#">Explore</a>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-sm-3 p-2">
                        <a href="#">
                            <div class="card">
                                <img class="card-img-top" src="assets/images/holiday/20.jpg" alt="Card image cap"
                                    style="height:200px;">
                                <div class="card-body">
                                    <h6 class="font-weight-bold">Beach Destinations</h6>
                                    <a class="float-right font-weight-bold text-primary" href="#">Explore</a>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
            <div class="carousel-item">
                <div class="row p-2">
                    <div class="col-sm-3 p-2">
                        <a href="#">
                            <div class="card">
                                <img class="card-img-top" src="assets/images/holiday/5.jpg" alt="Card image cap"
                                    style="height:200px;">
                                <div class="card-body">
                                    <h6 class="font-weight-bold">Weekend Getaways</h6>
                                    <a class="float-right font-weight-bold text-primary" href="#">Explore</a>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-sm-3 p-2">
                        <a href="#">
                            <div class="card">
                                <img class="card-img-top" src="assets/images/holiday/6.jpg" alt="Card image cap"
                                    style="height:200px;">
                                <div class="card-body">
                                    <h6 class="font-weight-bold">Hill Stations</h6>
                                    <a class="float-right font-weight-bold text-primary" href="#">Explore</a>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-sm-3 p-2">
                        <a href="#">
                            <div class="card">
                                <img class="card-img-top" src="assets/images/holiday/7.jpg" alt="Card image cap"
                                    style="height:200px;">
                                <div class="card-body">
                                    <h6 class="font-weight-bold">Adventure Destinations</h6>
                                    <a class="float-right font-weight-bold text-primary" href="#">Explore</a>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-sm-3 p-2">
                        <a href="#">
                            <div class="card">
                                <img class="card-img-top" src="assets/images/holiday/8.jpg" alt="Card image cap"
                                    style="height:200px;">
                                <div class="card-body">
                                    <h6 class="font-weight-bold">Heritage Destinations</h6>
                                    <a class="float-right font-weight-bold text-primary" href="#">Explore</a>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
            <div class="carousel-item">
                <div class="row p-2">
                    <div class="col-sm-3 p-2">
                        <a href="#">
                            <div class="card">
                                <img class="card-img-top" src="assets/images/holiday/1.jpg" alt="Card image cap"
                                    style="height:200px;">
                                <div class="card-body">
                                    <h6 class="font-weight-bold">Honeymoon Destinations</h6>
                                    <a class="float-right font-weight-bold text-primary" href="#">Explore</a>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-sm-3 p-2">
                        <a href="#">
                            <div class="card">
                                <img class="card-img-top" src="assets/images/holiday/2.jpg" alt="Card image cap"
                                    style="height:200px;">
                                <div class="card-body">
                                    <h6 class="font-weight-bold">Romantic Destinations</h6>
                                    <a class="float-right font-weight-bold text-primary" href="#">Explore</a>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-sm-3 p-2">
                        <a href="#">
                            <div class="card">
                                <img class="card-img-top" src="assets/images/holiday/3.jpg" alt="Card image cap"
                                    style="height:200px;">
                                <div class="card-body">
                                    <h6 class="font-weight-bold">International Destinations</h6>
                                    <a class="float-right font-weight-bold text-primary" href="#">Explore</a>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-sm-3 p-2">
                        <a href="#">
                            <div class="card">
                                <img class="card-img-top" src="assets/images/holiday/4.jpg" alt="Card image cap"
                                    style="height:200px;">
                                <div class="card-body">
                                    <h6 class="font-weight-bold">Beach Destinations</h6>
                                    <a class="float-right font-weight-bold text-primary" href="#">Explore</a>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- Desktiop End View -->
