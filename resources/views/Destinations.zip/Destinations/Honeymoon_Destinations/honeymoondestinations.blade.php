@extends('layouts.master')
@section('title', 'Wagnistrip')

  <link rel="stylesheet" href="{{('assets/css/destinationcss/honeymoondestinations.css')}}">
  <!--Deskstop view-->

  <div class="contain">
    <h2 style="margin-top:100px;">Honeymoon Destinations</h2>
    <div class="card-1">
    <div class="grid grid-three-column">
      <div class="bali">
        <img src="{{('assets/images/honeymoondestination/Bali.png')}}" alt="Bali Image">
        <div class="overlay">
            <a href="">Bali</a>
        </div>
      </div>
      <div class="italy">
        <img src="{{('assets/images/honeymoondestination/itally image .png')}}" alt="Italy Image">
        <div class="overlay">
            <a href="">Italy</a>
        </div>
      </div>
      <div class="kerala">
        <img src="{{('assets/images/honeymoondestination/kerala image .png')}}" alt="Kerala Image">
        <div class="overlay">
            <a href="">Kerala</a>
        </div>
      </div>
    </div>
</div>
<div class="card-2">
    <div class="grid grid-three-column">
      <div class="phuket">
        <img src="{{('assets/images/honeymoondestination/Phuket.png')}}" alt="Phuket Image">
        <div class="overlay">
            <a href="">Phuket</a>
        </div>
      </div>
      <div class="shimla">
        <img src="{{('assets/images/honeymoondestination/shimla image .png')}}" alt="Shimla Image">
        <div class="overlay">
            <a href="">Shimla</a>
        </div>
      </div>
      <div class="thailand">
        <img src="{{('assets/images/honeymoondestination/Thailand  image .png')}}" alt="Thailand Image">
        <div class="overlay">
            <a href="">Thailand</a>
        </div>
      </div>
    </div>
</div>
</div>

<x-footer />